CREATE TABLE example 
	(
     sid int, 
     sname varchar(20), 
     rating int,
     age float
    );

INSERT INTO example
(sid, sname, rating, age)
VALUES
(22, 'Dustin', 7, 45.0),
(31, 'Lubber', 8, 55.5),
(71, 'Zorba', 10, 16.0),
(64, 'Horatio', 7, 35.0),
(92, 'Frodo', 1, 28.0),
(38, 'Sam', 1, 30.0),
(29, 'Brutus', 1, 33.0),
(58, 'Rusty', 10, 35.0);

