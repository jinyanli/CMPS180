Database Projects

Simple database schema,
and database access with Psql.
